1. Client-Server

2. HTTP Protocol and HTTP methods

3. artifact, dependency, maven central repository, maven

4. How objects are created in Java

5. Spring Container i.e IOC Container

6. Springboot REST application architecture (controller, service, repository/DAO)

HTTP Status Code, State vs Stateless, 

IOC - "Inversion of Control"
Dependency Injection - (Field Injection, Constructor Injection)
@Autowired


7. JDBC -> Hibernate -> JPA

8. Spring annotations - (@SpringbootApplication, @RestController, @RequestMapping, @GetMapping, @PostMapping, 
                    @PutMapping, @DeleteMapping, @Component, @Service, @Repository)

9. JPA annotations - (@Entity, @Table, @Id, @GeneratedValue, relations like one to many and all)

10. Bean Scope - singleton, prototype, session, global....
